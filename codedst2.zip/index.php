
<!DOCTYPE html>
<html>
<head><style>img[alt="www.000webhost.com"]{display:none;}</style>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1 , maximum-scale=1, user-scalable=no, viewport-fit=cover">
	<title>Trung tâm nạp thẻ Garena</title>
    <link href="css/base.css" rel="stylesheet" />
    <link rel="stylesheet" href="js/slick/slick.css">
    <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="js/slick/slick.js"></script>
    <link href="css/style.css" rel="stylesheet" />

</head>
<body>
    <div class="s-header-1">
        <div class="container align-items--between">
            <a href="index.html" class="hd-logo"><img src="images/logogarena.png" alt=""></a>
            <ul>
                <li><a href=""><img src="images/user.jpg" alt="">Đăng nhập</a></li> <!-- LINK -->
                <li><a href="https://hotro.garena.vn">Chăm sóc khách hàng</a></li> <!-- LINK -->
            </ul>
        </div>
    </div> <div class="s-slide-1"> <div class="container"> <div class="b-sslide-ratio"> <div class="slick-slider"> <a href="https://shopeepay.vn/khuyen-mai/napthevn/"><img src="images/slide_1.jpg" alt="" /></a> <!-- LINK --> <!--<a href="https://shopeepay.vn/khuyen-mai/naptheTet/"><img src="images/slide_2.jpg" alt="" /></a> --><!-- LINK --> </div>
            </div>
        </div>
    </div>

    <div class="s-section-1">
        <div class="container">
            <h2 class="s_title"><span>Chọn game để nạp</span></h2>
            <div class="row row-flex">
                <div class="col-6 col-sm-4">
                    <a href="lienquan.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/lq.png" alt="">
                        <h3>Liên Quân Mobile</h3>
                    </a>
                </div>
                <div class="col-6 col-sm-4">
                    <a href="./freefire.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/faifai.png" alt="">
                        <h3>Free Fire</h3>
                    </a>
                </div>
                <div class="col-6 col-sm-4">
                    <a href="./so.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/icon.png" alt="">
                        <h3>Nạp Sò</h3>
                    </a>
                </div>
                <div class="col-6 col-sm-4">
                    <a href="./fo4.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/fifa.png" alt="">
                        <h3>FIFA Online 4 (VN)</h3>
                    </a>
                </div>
                <div class="col-6 col-sm-4">
                    <a href="./fo4m.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/fifa4.png" alt="">
                        <h3>FIFA Online 4 M VN</h3>
                    </a>
                </div>
                <div class="col-6 col-sm-4">
                    <a href="./blade.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/bns.png" alt="">
                        <h3>Blade and Soul</h3>
                    </a>
                </div>
                <div class="col-6 col-sm-4">
                    <a href="./lol.php" class="b-card-1"> <!-- LINK -->
                        <img src="images/lol.png" alt="">
                        <h3>Liên Minh Huyền Thoại</h3>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="s-pre-1">
        <div class="container">
            <a href="https://hotro.garena.vn"><img src="images/user.jpg" alt="">Chăm sóc khách hàng</a> <!-- LINK -->
        </div>
    </div>

    <div class="s-foolter-1">
        <div class="container">
            <ul>
                <li>CÔNG TY CỔ PHẦN PHÁT TRIỂN THỂ THAO ĐIỆN TỬ VIỆT NAM</li>
                <li>Giấy CNĐKKD số 0104459874, cấp lần đầu ngày 06/02/2009 | Cơ quan cấp: Phòng Đăng ký kinh doanh- Sở Kế hoạch và đầu tư TP Hồ Chí Minh</li>
                <li>Địa chỉ trụ sở 2: Tầng 15, Tòa nhà Phú Mỹ Hưng, số 8 đường Hoàng Văn Thái, Phường Tân Phú, Quận 7, TP Hồ Chí Minh, Việt Nam</li>
                <li>Điện thoại: 024 73053939</li>
            </ul>
            <ul>
                <li><a href="https://napthe.vn/faq">Câu hỏi thường gặp</a></li> <!-- LINK -->
                <li><a href="https://napthe.vn/terms">Điều khoản dịch vụ</a></li> <!-- LINK -->
                <li><a href="https://napthe.vn/privacy">Chính sách bảo mật</a></li> <!-- LINK -->
            </ul>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.s-slide-1 .slick-slider').slick();
        });
    </script>
</body>
</html>